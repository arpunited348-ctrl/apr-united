alter table profiles enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table subscriptions enable row level security;
alter table journal_entries enable row level security;

-- Profiles
create policy "users can view own profile" on profiles
for select using (auth.uid() = id);

create policy "users can update own profile" on profiles
for update using (auth.uid() = id);

create policy "users can insert own profile" on profiles
for insert with check (auth.uid() = id);

-- Conversations
create policy "users can view own conversations" on conversations
for select using (auth.uid() = user_id);

create policy "users can insert own conversations" on conversations
for insert with check (auth.uid() = user_id);

create policy "users can update own conversations" on conversations
for update using (auth.uid() = user_id);

create policy "users can delete own conversations" on conversations
for delete using (auth.uid() = user_id);

-- Messages
create policy "users can view own messages" on messages
for select using (
  exists (
    select 1 from conversations
    where conversations.id = messages.conversation_id
      and conversations.user_id = auth.uid()
  )
);

create policy "users can insert own messages" on messages
for insert with check (
  exists (
    select 1 from conversations
    where conversations.id = messages.conversation_id
      and conversations.user_id = auth.uid()
  )
);

-- Subscriptions
create policy "users can view own subscriptions" on subscriptions
for select using (auth.uid() = user_id);

-- Journal entries
create policy "users can view own journal entries" on journal_entries
for select using (auth.uid() = user_id);

create policy "users can insert own journal entries" on journal_entries
for insert with check (auth.uid() = user_id);

create policy "users can update own journal entries" on journal_entries
for update using (auth.uid() = user_id);

create policy "users can delete own journal entries" on journal_entries
for delete using (auth.uid() = user_id);
