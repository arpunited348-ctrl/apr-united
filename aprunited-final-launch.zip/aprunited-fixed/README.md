# APR United — Monorepo

Two production-ready Next.js apps under one monorepo.

| App | Domain | Stack |
|-----|--------|-------|
| `apps/apr-united-web` | aprunited.io | Next.js 15, Tailwind |
| `apps/sootheai-web` | sootheai.aprunited.io | Next.js 14, Supabase, OpenAI, Razorpay |

---

## SootheAI — What's in the box

- **Google OAuth** via Supabase (`/login` → `/auth/callback` → `/dashboard`)
- **Middleware auth guard** on `/chat` and `/dashboard` (server-side, no flash)
- **AI chat** with full conversation history passed on every request (`gpt-4o-mini`)
- **Mood tracking** dashboard reading from `mood_entries` table
- **Razorpay checkout** on `/pricing` — creates order server-side, opens Razorpay modal
- **NavBar** with dynamic auth state (shows Dashboard/Chat/Logout when signed in)
- **Auto profile creation** via Supabase trigger on signup

---

## Quick start

```bash
# Install all workspaces
npm install

# Run APR United site (localhost:3000)
npm run dev:apr

# Run SootheAI (localhost:3001)
npm run dev:soothe
```

---

## SootheAI setup

### 1. Supabase
1. Create a new project at supabase.com
2. Go to SQL Editor → run `apps/sootheai-web/scripts/schema.sql`
3. Go to Authentication → Providers → enable **Google**
4. Add callback URL: `http://localhost:3001/auth/callback`
5. For production add: `https://sootheai.aprunited.io/auth/callback`

### 2. Environment variables
Copy `apps/sootheai-web/.env.example` → `apps/sootheai-web/.env.local` and fill in:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
OPENAI_API_KEY=
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=
NEXT_PUBLIC_RAZORPAY_KEY_ID=
NEXT_PUBLIC_SITE_URL=https://sootheai.aprunited.io
```

### 3. Vercel deploy
- Create **two Vercel projects** — one per app folder
- Set root directory to `apps/sootheai-web` or `apps/apr-united-web`
- Add env vars from `.env.example`

---

## Cloudflare DNS

| Record | Name | Value |
|--------|------|-------|
| A | `@` | `76.76.21.21` |
| CNAME | `www` | `cname.vercel-dns-0.com` |
| CNAME | `sootheai` | `cname.vercel-dns-0.com` |

SSL/TLS mode: **Full (strict)**

---

## What to build next
- Save chat messages to Supabase per conversation
- Conversation sidebar with history
- Daily mood check-in form in dashboard
- Plan-based chat rate limiting
- Crisis safety escalation screen
- Admin dashboard
- Email onboarding flow
