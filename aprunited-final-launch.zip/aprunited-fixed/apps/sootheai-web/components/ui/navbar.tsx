'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase-browser';

export function NavBar() {
  const router = useRouter();
  const [loggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    const supabase = createClient();
    supabase.auth.getSession().then(({ data }) => setLoggedIn(!!data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      setLoggedIn(!!session);
    });
    return () => subscription.unsubscribe();
  }, []);

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.replace('/');
  }

  return (
    <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
      <Link href="/" className="flex items-center gap-2">
        <span className="text-xl font-bold text-cyan-400">SootheAI</span>
        <span className="rounded-full bg-white/10 px-2 py-0.5 text-xs text-slate-400">by APR United</span>
      </Link>
      <nav className="flex items-center gap-5 text-sm text-slate-300">
        <Link href="/pricing" className="hover:text-white transition-colors">Pricing</Link>
        {loggedIn ? (
          <>
            <Link href="/dashboard" className="hover:text-white transition-colors">Dashboard</Link>
            <Link href="/chat" className="hover:text-white transition-colors">Chat</Link>
            <button
              onClick={handleLogout}
              className="rounded-xl border border-white/10 px-3 py-1.5 text-slate-400 hover:text-white transition-colors"
            >
              Logout
            </button>
          </>
        ) : (
          <Link
            href="/login"
            className="rounded-xl bg-cyan-500 px-4 py-1.5 font-medium text-slate-950 hover:opacity-90 transition-opacity"
          >
            Get Started
          </Link>
        )}
      </nav>
    </header>
  );
}
