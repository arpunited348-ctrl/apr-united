'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';

type Message = {
  role: 'user' | 'assistant';
  content: string;
};

export function ChatBox() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    const nextMessages: Message[] = [...messages, { role: 'user', content: userMessage }];
    setMessages(nextMessages);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // Send full history so AI has context
        body: JSON.stringify({ message: userMessage, history: messages })
      });

      const data = await res.json();
      setMessages([...nextMessages, {
        role: 'assistant',
        content: data.reply ?? 'I am here with you.'
      }]);
    } catch {
      setMessages([...nextMessages, {
        role: 'assistant',
        content: 'Something went wrong. Please try again.'
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex w-full max-w-4xl flex-col gap-4">
      <div className="min-h-[420px] rounded-3xl border border-white/10 bg-white/5 p-4 overflow-y-auto">
        <div className="space-y-4">
          {messages.length === 0 && (
            <p className="text-slate-400 text-sm">Tell me what's on your mind. I'm here to listen. ✨</p>
          )}
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`max-w-[85%] rounded-2xl p-4 text-sm ${
                msg.role === 'user'
                  ? 'ml-auto bg-cyan-500 text-slate-950'
                  : 'bg-slate-800 text-white'
              }`}
            >
              {msg.content}
            </div>
          ))}
          {loading && (
            <div className="rounded-2xl bg-slate-800 p-4 text-sm text-slate-400">
              SootheAI is thinking…
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </div>
      <div className="flex gap-3">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
          placeholder="Tell me what you're feeling..."
          className="flex-1 rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 text-sm outline-none focus:border-cyan-500/50 transition-colors"
        />
        <Button onClick={sendMessage} disabled={loading || !input.trim()}>
          {loading ? '…' : 'Send'}
        </Button>
      </div>
    </div>
  );
}
