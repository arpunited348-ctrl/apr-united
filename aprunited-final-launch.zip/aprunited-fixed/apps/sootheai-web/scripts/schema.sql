-- Run this in your Supabase SQL editor

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text unique,
  avatar_url text,
  plan text default 'free',
  created_at timestamptz default now()
);

create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text default 'New Conversation',
  created_at timestamptz default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant','system')),
  content text not null,
  created_at timestamptz default now()
);

create table if not exists mood_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  mood_score int not null check (mood_score between 1 and 5),
  note text,
  created_at timestamptz default now()
);

-- Row Level Security
alter table profiles enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table mood_entries enable row level security;

create policy "Users manage own profile"
on profiles for all
using (auth.uid() = id)
with check (auth.uid() = id);

create policy "Users manage own conversations"
on conversations for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "Users manage own mood entries"
on mood_entries for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "Users manage messages in own conversations"
on messages for all
using (
  exists (
    select 1 from conversations
    where conversations.id = messages.conversation_id
    and conversations.user_id = auth.uid()
  )
)
with check (
  exists (
    select 1 from conversations
    where conversations.id = messages.conversation_id
    and conversations.user_id = auth.uid()
  )
);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
