import { NextResponse } from 'next/server';
import Razorpay from 'razorpay';

const PLAN_AMOUNTS: Record<string, number> = {
  pro: 9900,      // ₹99 in paise
  premium: 29900  // ₹299 in paise
};

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!
});

export async function POST(req: Request) {
  try {
    const { plan } = await req.json();

    const amount = PLAN_AMOUNTS[plan];
    if (!amount) {
      return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });
    }

    const order = await razorpay.orders.create({
      amount,
      currency: 'INR',
      receipt: `receipt_${plan}_${Date.now()}`
    });

    return NextResponse.json({ orderId: order.id, amount, currency: 'INR' });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Unable to create order' }, { status: 500 });
  }
}
