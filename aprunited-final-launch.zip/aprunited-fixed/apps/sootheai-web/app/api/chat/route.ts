import { NextResponse } from 'next/server';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

type ChatMessage = { role: 'user' | 'assistant' | 'system'; content: string };

export async function POST(req: Request) {
  try {
    const { message, history } = await req.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'Invalid message' }, { status: 400 });
    }

    // Build prior messages from history, keeping only user/assistant turns
    const priorMessages: ChatMessage[] = Array.isArray(history)
      ? history
          .filter((m: ChatMessage) => m.role === 'user' || m.role === 'assistant')
          .map((m: ChatMessage) => ({ role: m.role, content: m.content }))
      : [];

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content:
            'You are SootheAI, a calm, emotionally supportive AI assistant built by APR United. You are empathetic, warm, non-judgmental, and concise. You are not a licensed therapist and should encourage emergency help if there is immediate self-harm risk. Never break character.'
        },
        ...priorMessages,
        { role: 'user', content: message }
      ]
    });

    const reply = completion.choices[0]?.message?.content || 'I am here with you.';
    return NextResponse.json({ reply });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to generate response.' }, { status: 500 });
  }
}
