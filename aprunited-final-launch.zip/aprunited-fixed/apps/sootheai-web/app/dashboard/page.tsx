import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase-server';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const MOOD_LABELS: Record<number, string> = {
  1: '😔 Very low',
  2: '😟 Low',
  3: '😐 Neutral',
  4: '🙂 Good',
  5: '😊 Great'
};

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect('/login');

  const { data: moods } = await supabase
    .from('mood_entries')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(7);

  const { data: conversations } = await supabase
    .from('conversations')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(5);

  const avgMood = moods?.length
    ? (moods.reduce((sum, m) => sum + m.mood_score, 0) / moods.length).toFixed(1)
    : null;

  return (
    <main className="mx-auto min-h-[calc(100vh-80px)] max-w-6xl px-6 py-12">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold">Your Dashboard</h1>
          <p className="mt-2 text-slate-300">Track how you feel and continue your support journey.</p>
        </div>
        <Link href="/chat"><Button>Open Chat →</Button></Link>
      </div>

      {/* Stats row */}
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <p className="text-sm text-slate-400">Total sessions</p>
          <p className="mt-1 text-3xl font-bold">{conversations?.length ?? 0}</p>
        </Card>
        <Card className="p-5">
          <p className="text-sm text-slate-400">Avg mood (7 days)</p>
          <p className="mt-1 text-3xl font-bold">{avgMood ? `${avgMood}/5` : '—'}</p>
        </Card>
        <Card className="p-5">
          <p className="text-sm text-slate-400">Plan</p>
          <p className="mt-1 text-3xl font-bold">Free</p>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Mood entries */}
        <Card className="md:col-span-2">
          <h2 className="text-xl font-semibold">Recent Mood Entries</h2>
          <div className="mt-4 space-y-3">
            {moods?.length ? moods.map((mood) => (
              <div key={mood.id} className="flex items-center justify-between rounded-2xl bg-white/5 px-4 py-3">
                <div>
                  <p className="font-medium">{MOOD_LABELS[mood.mood_score] ?? `${mood.mood_score}/5`}</p>
                  <p className="text-sm text-slate-400">{mood.note || 'No note added'}</p>
                </div>
                <p className="text-xs text-slate-500">
                  {new Date(mood.created_at).toLocaleDateString()}
                </p>
              </div>
            )) : (
              <p className="text-slate-400">No mood entries yet. Log your first from the chat.</p>
            )}
          </div>
        </Card>

        {/* Quick actions */}
        <Card>
          <h2 className="text-xl font-semibold">Quick Actions</h2>
          <div className="mt-4 space-y-3">
            <Link href="/chat"><Button className="w-full">Talk to SootheAI</Button></Link>
            <Link href="/pricing"><Button className="w-full bg-white/10 text-white hover:bg-white/20">Upgrade Plan</Button></Link>
          </div>
          <div className="mt-6 rounded-2xl bg-white/5 p-4 text-xs text-slate-400 border border-white/10">
            SootheAI is a product by{' '}
            <a href="https://aprunited.io" className="text-cyan-400 hover:underline">APR United</a>.
          </div>
        </Card>
      </div>
    </main>
  );
}
