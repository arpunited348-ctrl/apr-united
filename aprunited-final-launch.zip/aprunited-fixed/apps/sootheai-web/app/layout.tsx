import './globals.css';
import type { Metadata } from 'next';
import { NavBar } from '@/components/ui/navbar';

export const metadata: Metadata = {
  title: 'SootheAI — by APR United',
  description: 'Your 24/7 AI emotional support companion, built by APR United.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-950 text-white">
        <NavBar />
        {children}
      </body>
    </html>
  );
}
