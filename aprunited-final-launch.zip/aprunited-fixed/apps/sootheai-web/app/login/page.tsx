'use client';

import { createClient } from '@/lib/supabase-browser';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import Link from 'next/link';

export default function LoginPage() {
  const signInWithGoogle = async () => {
    const supabase = createClient();
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth/callback`
      }
    });
  };

  return (
    <main className="flex min-h-[calc(100vh-80px)] items-center justify-center px-6">
      <Card className="w-full max-w-md text-center">
        <div className="mb-2 text-sm text-slate-400">SootheAI · by APR United</div>
        <h1 className="text-3xl font-bold">Welcome to SootheAI</h1>
        <p className="mt-3 text-slate-300">Start your private support journey.</p>
        <Button onClick={signInWithGoogle} className="mt-6 w-full">
          Continue with Google
        </Button>
        <p className="mt-6 text-xs text-slate-500">
          By signing in, you agree to our{' '}
          <Link href="https://aprunited.io/terms" className="text-slate-400 hover:underline">Terms</Link>
          {' '}and{' '}
          <Link href="https://aprunited.io/privacy" className="text-slate-400 hover:underline">Privacy Policy</Link>.
        </p>
      </Card>
    </main>
  );
}
