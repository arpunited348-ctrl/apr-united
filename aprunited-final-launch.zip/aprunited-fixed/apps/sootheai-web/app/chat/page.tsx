import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase-server';
import { ChatBox } from '@/components/chat/chat-box';

export default async function ChatPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect('/login');

  return (
    <main className="min-h-[calc(100vh-80px)] px-6 py-12">
      <div className="mx-auto mb-8 max-w-4xl">
        <h1 className="text-4xl font-bold">Your private safe space</h1>
        <p className="mt-2 text-slate-300">Talk openly. SootheAI listens with empathy.</p>
      </div>
      <ChatBox />
    </main>
  );
}
