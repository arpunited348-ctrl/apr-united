import Link from 'next/link';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function HomePage() {
  return (
    <main className="mx-auto flex min-h-[calc(100vh-80px)] max-w-6xl flex-col items-center justify-center px-6 py-20">
      <div className="grid items-center gap-10 md:grid-cols-2">
        <div>
          <div className="mb-4 flex items-center gap-2">
            <span className="text-cyan-300 text-sm font-medium">SootheAI</span>
            <span className="text-slate-500">·</span>
            <Link href="https://aprunited.io" className="text-slate-400 text-sm hover:text-slate-200 transition-colors">
              an APR United product
            </Link>
          </div>
          <h1 className="text-5xl font-bold leading-tight md:text-6xl">
            Talk to someone who understands — anytime, anywhere.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-slate-300">
            Your personal emotional support AI with private chat, daily mood tracking, and a calm dashboard built for healing.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link href="/login"><Button>Start Free</Button></Link>
            <Link href="/pricing"><Button className="bg-white/10 text-white hover:bg-white/20">See Pricing</Button></Link>
          </div>
        </div>
        <Card>
          <h2 className="text-2xl font-semibold">Why users stay</h2>
          <ul className="mt-4 space-y-3 text-slate-300">
            <li className="flex items-start gap-2"><span className="text-cyan-400 mt-0.5">✓</span> Private AI chat support</li>
            <li className="flex items-start gap-2"><span className="text-cyan-400 mt-0.5">✓</span> Mood tracking and emotional trends</li>
            <li className="flex items-start gap-2"><span className="text-cyan-400 mt-0.5">✓</span> Chat history that feels continuous</li>
            <li className="flex items-start gap-2"><span className="text-cyan-400 mt-0.5">✓</span> Always on, judgment-free</li>
          </ul>
          <div className="mt-6 rounded-2xl bg-white/5 p-4 text-sm text-slate-400 border border-white/10">
            A product by <Link href="https://aprunited.io" className="text-cyan-400 hover:underline">APR United</Link> — a startup studio building AI-first digital products.
          </div>
        </Card>
      </div>
    </main>
  );
}
