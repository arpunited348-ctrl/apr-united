'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { createClient } from '@/lib/supabase-browser';

const plans = [
  {
    name: 'Free',
    price: '₹0',
    plan: 'free',
    desc: 'Get started with basic support.',
    features: ['Limited chats per day', 'Basic mood tracking', 'Dashboard access']
  },
  {
    name: 'Pro',
    price: '₹99/mo',
    plan: 'pro',
    desc: 'For consistent daily support.',
    features: ['More chats per day', 'Priority responses', 'Full chat history']
  },
  {
    name: 'Premium',
    price: '₹299/mo',
    plan: 'premium',
    desc: 'For deep, ongoing guided support.',
    features: ['Unlimited chats', 'Future voice mode', 'Deep mood insights', 'Priority features']
  }
];

declare global {
  interface Window {
    Razorpay: new (options: Record<string, unknown>) => { open(): void };
  }
}

function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (document.getElementById('rzp-script')) { resolve(true); return; }
    const s = document.createElement('script');
    s.id = 'rzp-script';
    s.src = 'https://checkout.razorpay.com/v1/checkout.js';
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export default function PricingPage() {
  const [loading, setLoading] = useState<string | null>(null);
  const [toast, setToast] = useState('');

  async function handlePlan(plan: string) {
    if (plan === 'free') { setToast('You are already on the free plan.'); return; }

    const supabase = createClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { window.location.href = '/login'; return; }

    setLoading(plan);
    const ok = await loadRazorpay();
    if (!ok) { setToast('Could not load payment gateway. Please try again.'); setLoading(null); return; }

    const res = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan })
    });
    const order = await res.json();
    if (order.error) { setToast(order.error); setLoading(null); return; }

    const rzp = new window.Razorpay({
      key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
      amount: order.amount,
      currency: order.currency,
      name: 'SootheAI',
      description: `${plan.charAt(0).toUpperCase() + plan.slice(1)} Plan — Monthly`,
      order_id: order.orderId,
      prefill: { email: session.user.email },
      theme: { color: '#06b6d4' },
      handler: () => {
        setToast(`You are now on the ${plan} plan. Welcome! 🎉`);
        setLoading(null);
      }
    });
    rzp.open();
    setLoading(null);
  }

  return (
    <main className="mx-auto min-h-[calc(100vh-80px)] max-w-6xl px-6 py-16">
      <div className="text-center">
        <p className="mb-3 text-sm uppercase tracking-widest text-cyan-400">Pricing</p>
        <h1 className="text-5xl font-bold">Choose your support plan</h1>
        <p className="mt-4 text-slate-300">Simple pricing designed for trust and continuity.</p>
      </div>

      {toast && (
        <div className="mx-auto mt-8 max-w-md rounded-2xl bg-cyan-500/10 border border-cyan-500/20 px-5 py-4 text-center text-sm text-cyan-200">
          {toast}
        </div>
      )}

      <div className="mt-12 grid gap-6 md:grid-cols-3">
        {plans.map((plan, i) => (
          <Card key={plan.name} className={i === 2 ? 'border-cyan-500/40 relative' : ''}>
            {i === 2 && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-cyan-500 px-3 py-1 text-xs font-semibold text-slate-950">
                Most popular
              </div>
            )}
            <h2 className="text-2xl font-semibold">{plan.name}</h2>
            <p className="mt-2 text-4xl font-bold">{plan.price}</p>
            <p className="mt-2 text-sm text-slate-400">{plan.desc}</p>
            <ul className="mt-5 space-y-2 text-sm text-slate-300">
              {plan.features.map((f) => (
                <li key={f} className="flex items-center gap-2">
                  <span className="text-cyan-400">✓</span> {f}
                </li>
              ))}
            </ul>
            <Button
              className="mt-8 w-full"
              onClick={() => handlePlan(plan.plan)}
              disabled={loading === plan.plan}
            >
              {loading === plan.plan ? 'Processing…' : `Get ${plan.name}`}
            </Button>
          </Card>
        ))}
      </div>

      <p className="mt-10 text-center text-xs text-slate-500">
        SootheAI is a product by <a href="https://aprunited.io" className="text-slate-400 hover:underline">APR United</a>.
        Payments powered by Razorpay. All prices in INR.
      </p>
    </main>
  );
}
