import Link from 'next/link';

export function Nav() {
  return (
    <header className="mb-10 flex items-center justify-between rounded-3xl border border-slate-200 bg-white px-5 py-4 shadow-sm">
      <Link href="/" className="text-lg font-semibold">APR United</Link>
      <nav className="flex gap-4 text-sm text-slate-600">
        <Link href="/startups">Startups</Link>
        <Link href="/founders">Founders</Link>
        <Link href="/about">About</Link>
        <Link href="/contact">Contact</Link>
      </nav>
    </header>
  );
}
