const founders = [
  { name: 'Prashant Thakur', role: 'CEO' },
  { name: 'Ankit Singh', role: 'MD' },
  { name: 'Raj Patwa', role: 'Vice President' }
];

export default function FoundersPage() {
  return (
    <main>
      <h1 className="mb-8 text-4xl font-semibold">Our Team</h1>
      <div className="grid gap-4 md:grid-cols-3">
        {founders.map((founder) => (
          <div key={founder.name} className="card p-6">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-sky-50 text-sky-700 font-semibold text-lg">
              {founder.name.charAt(0)}
            </div>
            <h2 className="text-xl font-semibold">{founder.name}</h2>
            <p className="mt-1 text-slate-500">{founder.role}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
