const startups = [
  {
    name: 'SootheAI',
    desc: 'AI-first emotional support platform. Private chat, mood tracking, and guided wellness — available 24/7.',
    href: 'https://sootheai.aprunited.io',
    tag: 'Live',
    tagColor: 'bg-emerald-100 text-emerald-700'
  },
  {
    name: 'WeddNear',
    desc: 'Wedding vendor marketplace. Find verified venues, photographers, caterers and more near you.',
    href: 'https://weddnear.io',
    tag: 'Live',
    tagColor: 'bg-emerald-100 text-emerald-700'
  },
  {
    name: 'More ventures',
    desc: 'APR United is actively building and validating new product ideas. Stay tuned.',
    href: '#',
    tag: 'Coming soon',
    tagColor: 'bg-slate-100 text-slate-500'
  }
];

export default function StartupsPage() {
  return (
    <main>
      <h1 className="mb-2 text-4xl font-semibold">Our Ventures</h1>
      <p className="mb-8 text-slate-500">Products we have built, validated, and are scaling.</p>
      <div className="grid gap-4 md:grid-cols-2">
        {startups.map((startup) => (
          <div key={startup.name} className="card p-6">
            <div className="flex items-start justify-between mb-3">
              <h2 className="text-2xl font-semibold">{startup.name}</h2>
              <span className={`rounded-full px-3 py-1 text-xs font-medium ${startup.tagColor}`}>
                {startup.tag}
              </span>
            </div>
            <p className="text-slate-600">{startup.desc}</p>
            {startup.href !== '#' && (
              <a
                href={startup.href}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center gap-1 font-medium text-sky-700 hover:underline"
              >
                Visit {startup.name} →
              </a>
            )}
          </div>
        ))}
      </div>
    </main>
  );
}
