export default function TermsPage() {
  return (
    <main className="max-w-3xl">
      <h1 className="mb-6 text-4xl font-semibold">Terms of Service</h1>
      <p className="text-sm text-slate-500 mb-8">Last updated: March 2026</p>
      <div className="space-y-6 text-slate-600 leading-relaxed">
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Acceptance of terms</h2>
          <p>By using APR United products, including SootheAI, you agree to these terms. If you do not agree, please do not use our services.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Use of services</h2>
          <p>Our services are provided for personal wellness and productivity purposes. You agree not to misuse them, attempt to reverse-engineer our systems, or use them for any unlawful purpose.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">SootheAI disclaimer</h2>
          <p>SootheAI is an AI-powered wellness tool and is not a substitute for professional mental health care. It is not a licensed therapist or medical provider. If you are in crisis, please contact emergency services or a qualified professional immediately.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Subscriptions and billing</h2>
          <p>Paid plans are billed monthly. You may cancel at any time. Refunds are handled on a case-by-case basis — contact us at <a href="mailto:hello@aprunited.io" className="text-sky-700 hover:underline">hello@aprunited.io</a> within 7 days of billing.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Limitation of liability</h2>
          <p>APR United is not liable for any indirect or consequential damages arising from your use of our services. Our liability is limited to the amount you paid us in the past 30 days.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Contact</h2>
          <p>Questions about these terms? Email <a href="mailto:hello@aprunited.io" className="text-sky-700 hover:underline">hello@aprunited.io</a>.</p>
        </section>
      </div>
    </main>
  );
}
