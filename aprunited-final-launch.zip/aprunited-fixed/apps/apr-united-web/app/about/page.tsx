export default function AboutPage() {
  return (
    <main className="max-w-3xl">
      <h1 className="mb-4 text-4xl font-semibold">About APR United</h1>
      <p className="text-lg text-slate-600 mb-6">
        APR United is a startup studio building products at the intersection of AI, usability, and commercial execution.
        We focus on identifying real problems, designing focused solutions, and scaling what works.
      </p>
      <div className="grid gap-4 sm:grid-cols-3 mb-8">
        <div className="rounded-2xl bg-slate-50 p-5">
          <p className="text-sm text-slate-500">Model</p>
          <p className="mt-2 font-semibold">Studio</p>
        </div>
        <div className="rounded-2xl bg-slate-50 p-5">
          <p className="text-sm text-slate-500">Focus</p>
          <p className="mt-2 font-semibold">AI + SaaS</p>
        </div>
        <div className="rounded-2xl bg-slate-50 p-5">
          <p className="text-sm text-slate-500">Goal</p>
          <p className="mt-2 font-semibold">Fundable products</p>
        </div>
      </div>
      <p className="text-slate-600">
        Our first product, SootheAI, is an AI-first emotional wellness platform. We are actively building, validating, and preparing our ventures for investment and scale.
      </p>
    </main>
  );
}
