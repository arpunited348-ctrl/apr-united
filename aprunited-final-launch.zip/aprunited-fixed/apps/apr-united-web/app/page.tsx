'use client';

import React, { useMemo, useState } from 'react';

const VALID_PAGES = ['home', 'about', 'founders', 'ventures', 'contact'];

function normalizePage(page: string) {
  return VALID_PAGES.includes(page) ? page : 'home';
}

function SectionTitle({ eyebrow, title, desc }: { eyebrow: string; title: string; desc?: string }) {
  return (
    <div className="text-center">
      <div className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">{eyebrow}</div>
      <h2 className="mt-4 text-3xl font-bold md:text-5xl">{title}</h2>
      {desc ? <p className="mx-auto mt-4 max-w-3xl text-slate-300">{desc}</p> : null}
    </div>
  );
}

function PageShell({ children }: { children: React.ReactNode }) {
  return <main className="mx-auto max-w-7xl px-6 py-16 md:py-20">{children}</main>;
}

export default function APRUnitedWebsite() {
  const founders = useMemo(
    () => [
      {
        name: 'Prashant Thakur',
        role: 'Chief Executive Officer',
        story: 'From Bihar • Under 26 • Co-founder who shaped the initial vision',
        bio: 'Prashant, originally from Bihar, met Ankit and Raj during Wakefit training in Hosur. That moment sparked the idea of building something of their own. Today, he leads APR United with strong focus on vision, product direction, and growth.',
        image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=900&q=80',
      },
      {
        name: 'Ankit Singh',
        role: 'Managing Director',
        story: 'Came from Chhattisgarh • Native Bihar • Builder mindset',
        bio: 'Ankit came from Chhattisgarh but his roots are in Bihar. He met Prashant and Raj during Wakefit training in Hosur, where they connected over ambition and startup dreams. He now drives execution, operations, and scaling for APR United.',
        image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=900&q=80',
      },
      {
        name: 'Raj Patwa',
        role: 'Vice President',
        story: 'From Uttar Pradesh • Growth & coordination focus',
        bio: 'Raj is from Uttar Pradesh and became part of the founding trio after meeting during Wakefit training in Hosur. With a shared dream of building a startup, he now focuses on expansion, coordination, and strengthening APR United ventures.',
        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=900&q=80',
      },
    ],
    []
  );

  const ventures = useMemo(
    () => [
      {
        name: 'SootheAI',
        tag: 'AI Wellness Platform',
        desc: 'A calming AI-powered support platform focused on emotional wellness, reflection, and everyday mental clarity.',
        status: 'Core Venture',
        audience: 'Students, professionals, and wellness-focused users',
        href: 'https://sootheai.aprunited.io',
      },
      {
        name: 'WeddNear',
        tag: 'Wedding Vendor Marketplace',
        desc: 'Find verified venues, photographers, caterers and more near you. The easiest way to plan your wedding.',
        status: 'Live Venture',
        audience: 'Couples planning weddings across India',
        href: 'https://weddnear.io',
      },
      {
        name: 'KrishiMitra AI',
        tag: 'Agri Advisory Platform',
        desc: 'An all-in-one AI farming assistant designed to help farmers with crop advice, weather updates, and smarter field decisions.',
        status: 'Growth Venture',
        audience: 'Farmers, agri-communities, and rural advisors',
        href: '#',
      },
      {
        name: 'Finance AI',
        tag: 'Smart Financial Assistant',
        desc: 'A digital finance guidance platform built to simplify money decisions, planning, and financial awareness for modern users.',
        status: 'Future Venture',
        audience: 'Young earners, families, and finance learners',
        href: '#',
      },
    ],
    []
  );

  const stats = useMemo(
    () => [
      { label: 'Venture Model', value: 'AI Startup Studio' },
      { label: 'Focus Areas', value: 'Wellness • Agri • Finance' },
      { label: 'Current Goal', value: 'Launch → Traction → Scale' },
    ],
    []
  );

  const values = useMemo(
    () => [
      'Build meaningful digital products',
      'Solve practical user problems',
      'Design premium and simple experiences',
      'Create ventures with real business value',
    ],
    []
  );

  const navItems = useMemo(
    () => [
      ['home', 'Home'],
      ['about', 'About'],
      ['founders', 'Founders'],
      ['ventures', 'Ventures'],
      ['contact', 'Contact'],
    ],
    []
  );

  const [page, setPage] = useState('home');
  const goToPage = (nextPage: string) => { setPage(normalizePage(nextPage)); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const currentPage = normalizePage(page);

  const HomePage = () => (
    <>
      <section className="relative overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(34,211,238,0.18),_transparent_35%),radial-gradient(circle_at_left,_rgba(59,130,246,0.14),_transparent_30%)]" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-6 py-20 md:grid-cols-2 md:py-28">
          <div>
            <div className="mb-4 inline-flex rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-1 text-sm text-cyan-300">
              APR United • AI Venture Studio 🚀
            </div>
            <h1 className="text-4xl font-bold leading-tight md:text-6xl">
              Building AI ventures with clarity, ambition, and real-world use.
            </h1>
            <p className="mt-6 max-w-2xl text-base text-slate-300 md:text-lg">
              APR United is a modern startup brand creating focused products across wellness, agriculture, and finance under one scalable ecosystem.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <button onClick={() => goToPage('ventures')} className="rounded-2xl bg-cyan-400 px-6 py-3 font-semibold text-slate-950 transition hover:scale-105">
                Explore Ventures
              </button>
              <button onClick={() => goToPage('founders')} className="rounded-2xl border border-white/15 px-6 py-3 font-semibold transition hover:border-cyan-300 hover:text-cyan-300">
                Meet the Founders
              </button>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {stats.map((item) => (
              <div key={item.label} className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-2xl backdrop-blur">
                <div className="text-sm text-cyan-300">{item.label}</div>
                <div className="mt-3 text-2xl font-bold">{item.value}</div>
              </div>
            ))}
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-2xl backdrop-blur md:col-span-2">
              <div className="text-sm text-cyan-300">What We Build</div>
              <p className="mt-3 text-sm leading-7 text-slate-300">
                APR United is designed to launch and grow multiple digital ventures under one premium parent brand with sharper focus, better positioning, and stronger long-term value.
              </p>
            </div>
          </div>
        </div>
      </section>
      <PageShell>
        <div className="grid gap-8 md:grid-cols-4">
          {values.map((value) => (
            <div key={value} className="rounded-3xl border border-white/10 bg-white/5 p-6 text-slate-200 shadow-xl">
              ✦ {value}
            </div>
          ))}
        </div>
        {/* Live ventures preview */}
        <div className="mt-16">
          <h3 className="mb-6 text-center text-2xl font-bold">Our Live Products</h3>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-3xl border border-cyan-500/20 bg-white/5 p-6">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bold text-xl">SootheAI</span>
                <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs text-emerald-300">Live</span>
              </div>
              <p className="text-slate-400 text-sm mb-4">AI emotional wellness platform — private chat, mood tracking, 24/7 support.</p>
              <a href="https://sootheai.aprunited.io" target="_blank" rel="noopener noreferrer" className="text-cyan-400 text-sm hover:underline">Visit SootheAI →</a>
            </div>
            <div className="rounded-3xl border border-cyan-500/20 bg-white/5 p-6">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bold text-xl">WeddNear</span>
                <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs text-emerald-300">Live</span>
              </div>
              <p className="text-slate-400 text-sm mb-4">Wedding vendor marketplace — venues, photographers, caterers near you.</p>
              <a href="https://weddnear.io" target="_blank" rel="noopener noreferrer" className="text-cyan-400 text-sm hover:underline">Visit WeddNear →</a>
            </div>
          </div>
        </div>
      </PageShell>
    </>
  );

  const AboutPage = () => (
    <PageShell>
      <SectionTitle eyebrow="About APR United" title="One parent brand powering multiple AI startup ideas" desc="APR United brings vision, structure, and execution into one platform so ideas can grow into real ventures with strong identity and market value." />
      <div className="mt-14 grid gap-10 md:grid-cols-2">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl">
          <h3 className="text-2xl font-bold">Our Mission</h3>
          <p className="mt-4 leading-8 text-slate-300">To build AI-first ventures that are useful, scalable, and category-defining. APR United exists to transform promising ideas into structured digital businesses.</p>
        </div>
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl">
          <h3 className="text-2xl font-bold">Our Vision</h3>
          <p className="mt-4 leading-8 text-slate-300">To become a recognized startup umbrella brand known for launching powerful AI solutions across high-impact sectors.</p>
        </div>
      </div>
      <div className="mt-10 rounded-3xl border border-white/10 bg-slate-900/80 p-8 shadow-2xl">
        <h3 className="text-2xl font-bold">Why APR United Matters</h3>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {['Stronger brand positioning for all products', 'Shared design, product, and growth thinking', 'Clear startup-to-scale structure', 'Better investor and buyer storytelling'].map((point) => (
            <div key={point} className="rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-slate-300">{point}</div>
          ))}
        </div>
      </div>
    </PageShell>
  );

  const FoundersPage = () => (
    <>
      <section className="relative border-b border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(34,211,238,0.15),_transparent_40%)]" />
        <div className="relative mx-auto max-w-6xl px-6 py-16 text-center">
          <h2 className="text-4xl font-bold md:text-6xl">Three Founders. One Direction.</h2>
          <p className="mt-5 mx-auto max-w-3xl text-slate-300">Different states. Same ambition. Met at Wakefit training in Hosur — turned conversations into a startup vision, and now building APR United as a scalable AI venture brand.</p>
          <div className="mt-10 rounded-3xl border border-white/10 bg-white/5 p-6 text-slate-400">📸 Founder Group Image (Add your real team photo here)</div>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-6 py-14">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-10 shadow-2xl">
          <h3 className="text-3xl font-bold">Why We Started</h3>
          <p className="mt-6 text-lg leading-8 text-slate-300">While working and training in Hosur, we realized something important — most people wait for opportunities, but founders create them. Coming from Bihar, Chhattisgarh, and Uttar Pradesh, we shared the same hunger to build something of our own. That became APR United.</p>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-6 py-10">
        <h3 className="text-center text-3xl font-bold">Execution Roles</h3>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[['CEO • Vision', 'Product direction, strategy, brand positioning, investor narrative.'], ['MD • Execution', 'Operations, product building, system execution, scaling workflows.'], ['VP • Growth', 'Expansion, partnerships, coordination, and growth strategies.']].map(([role, desc]) => (
            <div key={role} className="rounded-2xl border border-white/10 bg-white/5 p-6">
              <div className="font-semibold text-cyan-300">{role}</div>
              <p className="mt-3 text-slate-300">{desc}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="mx-auto max-w-5xl px-6 py-12">
        <div className="grid gap-6 text-center md:grid-cols-3">
          {[['Origin', 'Bihar • Chhattisgarh • Uttar Pradesh'], ['Meeting', 'Wakefit Training • Hosur'], ['Outcome', 'APR United 🚀']].map(([label, val]) => (
            <div key={label} className="rounded-2xl border border-white/10 bg-white/5 p-6">
              <div className="font-semibold text-cyan-300">{label}</div>
              <div className="mt-2">{val}</div>
            </div>
          ))}
        </div>
      </section>
      <PageShell>
        <SectionTitle eyebrow="Founders" title="Young founders building a scalable startup" desc="A strong execution-focused team with clear roles, aligned vision, and long-term startup ambition." />
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {founders.map((founder) => (
            <div key={founder.name} className="overflow-hidden rounded-3xl border border-white/10 bg-white/5 shadow-2xl">
              <img src={founder.image} alt={founder.name} className="h-72 w-full object-cover" loading="lazy" />
              <div className="p-6">
                <div className="text-sm uppercase tracking-[0.2em] text-cyan-300">{founder.role}</div>
                <h3 className="mt-2 text-2xl font-bold">{founder.name}</h3>
                <p className="mt-3 text-sm text-cyan-200">{founder.story}</p>
                <p className="mt-4 leading-7 text-slate-300">{founder.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </PageShell>
      <section className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 py-16">
        <div className="mx-auto max-w-5xl px-6 text-center">
          <h3 className="text-3xl font-bold">Founder Strength</h3>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {[['Under 26', 'High energy, long-term builders'], ['Multi-State', 'Diverse thinking & backgrounds'], ['Execution Ready', 'Already building real products']].map(([val, label]) => (
              <div key={val} className="rounded-2xl border border-white/10 bg-white/5 p-6">
                <div className="text-2xl font-bold">{val}</div>
                <div className="text-slate-400">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );

  const VenturesPage = () => (
    <PageShell>
      <SectionTitle eyebrow="Ventures" title="Focused products under APR United" desc="Each venture targets a clear user problem and contributes to the larger APR United vision of building a strong AI startup ecosystem." />
      <div className="mt-12 grid gap-6 md:grid-cols-2">
        {ventures.map((venture) => (
          <div key={venture.name} className="rounded-3xl border border-white/10 bg-slate-900/80 p-6 shadow-xl transition hover:-translate-y-1 hover:border-cyan-300/40">
            <div className="flex items-center justify-between gap-3">
              <div className="text-sm text-cyan-300">{venture.tag}</div>
              <div className="rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-xs text-cyan-300">{venture.status}</div>
            </div>
            <h3 className="mt-3 text-2xl font-bold">{venture.name}</h3>
            <p className="mt-4 leading-7 text-slate-300">{venture.desc}</p>
            <div className="mt-3 text-sm text-slate-400">Ideal audience: {venture.audience}</div>
            {venture.href !== '#' && (
              <a href={venture.href} target="_blank" rel="noopener noreferrer" className="mt-4 inline-block text-cyan-400 text-sm hover:underline">
                Visit {venture.name} →
              </a>
            )}
          </div>
        ))}
      </div>
    </PageShell>
  );

  const ContactPage = () => (
    <PageShell>
      <SectionTitle eyebrow="Contact" title="Let's build something meaningful" desc="Connect with APR United for collaboration, partnerships, startup discussions, or venture opportunities." />
      <div className="mt-12 grid gap-8 md:grid-cols-2">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl">
          <h3 className="text-2xl font-bold">Get in Touch</h3>
          <div className="mt-6 space-y-4 text-slate-300">
            <div>📧 hello@aprunited.io</div>
            <div>📍 India</div>
            <div>🚀 Focus: AI ventures, digital products, startup collaborations</div>
          </div>
          <div className="mt-8 space-y-3">
            <a href="https://sootheai.aprunited.io" target="_blank" rel="noopener noreferrer" className="block rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-sm hover:border-cyan-300/40 transition">SootheAI → sootheai.aprunited.io</a>
            <a href="https://weddnear.io" target="_blank" rel="noopener noreferrer" className="block rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-sm hover:border-cyan-300/40 transition">WeddNear → weddnear.io</a>
          </div>
        </div>
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl">
          <h3 className="text-2xl font-bold">Quick Contact Form</h3>
          <form className="mt-6 space-y-4" onSubmit={(e) => e.preventDefault()}>
            <input className="w-full rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 outline-none placeholder:text-slate-500 focus:border-cyan-500/50" placeholder="Your name" aria-label="Your name" />
            <input className="w-full rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 outline-none placeholder:text-slate-500 focus:border-cyan-500/50" placeholder="Your email" aria-label="Your email" type="email" />
            <textarea className="h-32 w-full rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 outline-none placeholder:text-slate-500 focus:border-cyan-500/50" placeholder="Your message" aria-label="Your message" />
            <button className="rounded-2xl bg-cyan-400 px-6 py-3 font-semibold text-slate-950 transition hover:scale-105 hover:bg-cyan-300">Send Message</button>
          </form>
        </div>
      </div>
    </PageShell>
  );

  const renderPage = () => {
    switch (currentPage) {
      case 'about': return <AboutPage />;
      case 'founders': return <FoundersPage />;
      case 'ventures': return <VenturesPage />;
      case 'contact': return <ContactPage />;
      default: return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-4">
          <div>
            <div className="text-2xl font-bold tracking-wide">APR United</div>
            <div className="text-xs uppercase tracking-[0.35em] text-cyan-300">Building the next wave of AI ventures</div>
          </div>
          <nav className="flex flex-wrap gap-2 md:gap-3" aria-label="Main navigation">
            {navItems.map(([key, label]) => (
              <button
                key={key}
                onClick={() => goToPage(key as string)}
                className={`rounded-full px-4 py-2 text-sm transition ${currentPage === key ? 'bg-cyan-400 text-slate-950' : 'border border-white/10 bg-white/5 text-slate-200 hover:border-cyan-300 hover:text-cyan-300'}`}
                aria-pressed={currentPage === key}
                type="button"
              >
                {label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {renderPage()}

      <footer className="border-t border-white/10 bg-slate-950">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 text-center text-sm text-slate-400 md:flex-row md:text-left">
          <div>© 2026 APR United. All rights reserved.</div>
          <div className="flex gap-6">
            <a href="https://sootheai.aprunited.io" className="hover:text-cyan-400 transition">SootheAI</a>
            <a href="https://weddnear.io" className="hover:text-cyan-400 transition">WeddNear</a>
          </div>
          <div>Built for vision, scale, and premium startup positioning.</div>
        </div>
      </footer>
    </div>
  );
}
