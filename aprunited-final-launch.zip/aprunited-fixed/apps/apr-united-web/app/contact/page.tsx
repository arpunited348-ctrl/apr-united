export default function ContactPage() {
  return (
    <main className="max-w-2xl">
      <h1 className="mb-4 text-4xl font-semibold">Contact</h1>
      <p className="text-slate-600 mb-6">
        We'd love to hear from you — whether you're a founder, investor, or potential collaborator.
      </p>
      <div className="rounded-2xl bg-slate-50 p-6 space-y-4">
        <div>
          <p className="text-sm text-slate-500">General inquiries</p>
          <a href="mailto:hello@aprunited.io" className="font-medium text-sky-700 hover:underline">hello@aprunited.io</a>
        </div>
        <div>
          <p className="text-sm text-slate-500">Investor relations</p>
          <a href="mailto:invest@aprunited.io" className="font-medium text-sky-700 hover:underline">invest@aprunited.io</a>
        </div>
      </div>
    </main>
  );
}
