export default function PrivacyPage() {
  return (
    <main className="max-w-3xl">
      <h1 className="mb-6 text-4xl font-semibold">Privacy Policy</h1>
      <p className="text-sm text-slate-500 mb-8">Last updated: March 2026</p>
      <div className="space-y-6 text-slate-600 leading-relaxed">
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Information we collect</h2>
          <p>We collect information you provide when creating an account — including your name, email address, and usage data within our products. For SootheAI, conversation data is stored to provide continuity of service.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">How we use your information</h2>
          <p>Your data is used solely to operate and improve our products. We do not sell your personal data to third parties. Payment processing is handled by Razorpay and subject to their privacy policy.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Data security</h2>
          <p>We use Supabase with row-level security policies to ensure that your data is only accessible by you. All connections are encrypted over HTTPS.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Your rights</h2>
          <p>You may request deletion of your account and associated data at any time by contacting us at <a href="mailto:hello@aprunited.io" className="text-sky-700 hover:underline">hello@aprunited.io</a>.</p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-950 mb-2">Contact</h2>
          <p>For privacy-related questions, email <a href="mailto:hello@aprunited.io" className="text-sky-700 hover:underline">hello@aprunited.io</a>.</p>
        </section>
      </div>
    </main>
  );
}
