import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'APR United — AI Venture Studio',
  description: 'APR United is a modern startup brand creating focused AI products across wellness, agriculture, and finance.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-950 text-white">{children}</body>
    </html>
  );
}
