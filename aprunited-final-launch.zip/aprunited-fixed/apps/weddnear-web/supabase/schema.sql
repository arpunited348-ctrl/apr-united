-- =============================================
-- WEDDNEAR / FINDNEAR — Full Database Schema
-- Run this in Supabase SQL Editor
-- =============================================

create extension if not exists pgcrypto;
create extension if not exists "uuid-ossp";

-- =============================================
-- PROFILES
-- =============================================
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text unique,
  phone text,
  avatar_url text,
  role text default 'user' check (role in ('user', 'vendor', 'admin')),
  created_at timestamptz default now()
);

-- =============================================
-- CATEGORIES
-- =============================================
create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  icon text,
  description text,
  created_at timestamptz default now()
);

insert into categories (name, slug, icon) values
  ('Venues', 'venues', '🏛️'),
  ('Photographers', 'photographers', '📷'),
  ('Caterers', 'caterers', '🍽️'),
  ('Decorators', 'decorators', '🌸'),
  ('Mehendi Artists', 'mehendi', '🖐️'),
  ('Makeup Artists', 'makeup', '💄'),
  ('DJ & Music', 'music', '🎵'),
  ('Pandit & Rituals', 'pandit', '🪔'),
  ('Videographers', 'videographers', '🎥'),
  ('Wedding Planners', 'planners', '📋')
on conflict (slug) do nothing;

-- =============================================
-- VENDORS
-- =============================================
create table if not exists vendors (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  business_name text not null,
  slug text unique,
  category_id uuid references categories(id),
  description text,
  price_min numeric,
  price_max numeric,
  price_unit text default 'per event',
  city text,
  state text,
  pincode text,
  lat numeric,
  lng numeric,
  cover_image text,
  gallery text[] default '{}',
  tags text[] default '{}',
  is_verified boolean default false,
  is_active boolean default true,
  avg_rating numeric(3,2) default 0,
  review_count int default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- =============================================
-- BOOKINGS / ENQUIRIES
-- =============================================
create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  vendor_id uuid not null references vendors(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  event_date date,
  event_type text,
  guest_count int,
  message text,
  status text default 'pending' check (status in ('pending', 'confirmed', 'cancelled', 'completed')),
  budget numeric,
  contact_name text,
  contact_phone text,
  contact_email text,
  vendor_response text,
  responded_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- =============================================
-- REVIEWS
-- =============================================
create table if not exists reviews (
  id uuid primary key default gen_random_uuid(),
  vendor_id uuid not null references vendors(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  booking_id uuid references bookings(id),
  rating int not null check (rating between 1 and 5),
  title text,
  body text,
  is_approved boolean default false,
  created_at timestamptz default now(),
  unique(vendor_id, user_id)
);

-- =============================================
-- WISHLIST
-- =============================================
create table if not exists wishlists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  vendor_id uuid not null references vendors(id) on delete cascade,
  created_at timestamptz default now(),
  unique(user_id, vendor_id)
);

-- =============================================
-- AUTO-UPDATE avg_rating ON REVIEW CHANGE
-- =============================================
create or replace function update_vendor_rating()
returns trigger as $$
begin
  update vendors
  set
    avg_rating = (
      select coalesce(round(avg(rating)::numeric, 2), 0)
      from reviews
      where vendor_id = coalesce(new.vendor_id, old.vendor_id)
        and is_approved = true
    ),
    review_count = (
      select count(*)
      from reviews
      where vendor_id = coalesce(new.vendor_id, old.vendor_id)
        and is_approved = true
    )
  where id = coalesce(new.vendor_id, old.vendor_id);
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_review_change
  after insert or update or delete on reviews
  for each row execute procedure update_vendor_rating();

-- =============================================
-- AUTO-CREATE PROFILE ON SIGNUP
-- =============================================
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- =============================================
-- AUTO-GENERATE VENDOR SLUG
-- =============================================
create or replace function generate_vendor_slug()
returns trigger as $$
begin
  if new.slug is null then
    new.slug := lower(regexp_replace(new.business_name, '[^a-zA-Z0-9]+', '-', 'g'))
      || '-' || substr(gen_random_uuid()::text, 1, 6);
  end if;
  return new;
end;
$$ language plpgsql;

create or replace trigger before_vendor_insert
  before insert on vendors
  for each row execute procedure generate_vendor_slug();

-- =============================================
-- ROW LEVEL SECURITY
-- =============================================
alter table profiles enable row level security;
alter table vendors enable row level security;
alter table bookings enable row level security;
alter table reviews enable row level security;
alter table wishlists enable row level security;
alter table categories enable row level security;

-- Profiles
create policy "Users manage own profile" on profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "Public can read profiles" on profiles
  for select using (true);

-- Categories (public read)
create policy "Public can read categories" on categories
  for select using (true);

-- Vendors
create policy "Public can view active vendors" on vendors
  for select using (is_active = true);
create policy "Vendor manages own listing" on vendors
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Admin manages all vendors" on vendors
  for all using (
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

-- Bookings
create policy "User sees own bookings" on bookings
  for select using (auth.uid() = user_id);
create policy "User creates bookings" on bookings
  for insert with check (auth.uid() = user_id);
create policy "User cancels own bookings" on bookings
  for update using (auth.uid() = user_id);
create policy "Vendor sees bookings for their listing" on bookings
  for select using (
    exists (select 1 from vendors where id = bookings.vendor_id and user_id = auth.uid())
  );
create policy "Vendor responds to bookings" on bookings
  for update using (
    exists (select 1 from vendors where id = bookings.vendor_id and user_id = auth.uid())
  );
create policy "Admin manages all bookings" on bookings
  for all using (
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

-- Reviews
create policy "Public can read approved reviews" on reviews
  for select using (is_approved = true);
create policy "User manages own reviews" on reviews
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Admin manages all reviews" on reviews
  for all using (
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

-- Wishlists
create policy "User manages own wishlist" on wishlists
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
