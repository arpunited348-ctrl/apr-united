export type Role = 'user' | 'vendor' | 'admin';
export type BookingStatus = 'pending' | 'confirmed' | 'cancelled' | 'completed';

export interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  avatar_url: string | null;
  role: Role;
  created_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
  description: string | null;
}

export interface Vendor {
  id: string;
  user_id: string;
  business_name: string;
  slug: string;
  category_id: string;
  description: string | null;
  price_min: number | null;
  price_max: number | null;
  price_unit: string;
  city: string | null;
  state: string | null;
  pincode: string | null;
  lat: number | null;
  lng: number | null;
  cover_image: string | null;
  gallery: string[];
  tags: string[];
  is_verified: boolean;
  is_active: boolean;
  avg_rating: number;
  review_count: number;
  created_at: string;
  updated_at: string;
  categories?: Category;
}

export interface Booking {
  id: string;
  vendor_id: string;
  user_id: string;
  event_date: string | null;
  event_type: string | null;
  guest_count: number | null;
  message: string | null;
  status: BookingStatus;
  budget: number | null;
  contact_name: string | null;
  contact_phone: string | null;
  contact_email: string | null;
  vendor_response: string | null;
  responded_at: string | null;
  created_at: string;
  vendors?: Vendor;
  profiles?: Profile;
}

export interface Review {
  id: string;
  vendor_id: string;
  user_id: string;
  booking_id: string | null;
  rating: number;
  title: string | null;
  body: string | null;
  is_approved: boolean;
  created_at: string;
  profiles?: Profile;
}
