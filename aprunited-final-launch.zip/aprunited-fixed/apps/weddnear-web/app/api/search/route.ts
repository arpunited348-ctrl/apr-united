import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';

// GET /api/search?q=photographer&city=Mumbai&category=photographers&lat=19.07&lng=72.87&radius=20
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const q = searchParams.get('q') ?? '';
    const city = searchParams.get('city') ?? '';
    const category = searchParams.get('category') ?? '';
    const lat = parseFloat(searchParams.get('lat') ?? '0');
    const lng = parseFloat(searchParams.get('lng') ?? '0');
    const radius = parseFloat(searchParams.get('radius') ?? '50'); // km
    const minPrice = searchParams.get('min_price');
    const maxPrice = searchParams.get('max_price');
    const minRating = searchParams.get('min_rating');
    const page = parseInt(searchParams.get('page') ?? '1');
    const limit = parseInt(searchParams.get('limit') ?? '12');
    const offset = (page - 1) * limit;

    const supabase = await createClient();

    let query = supabase
      .from('vendors')
      .select(`
        *,
        categories(id, name, slug, icon)
      `, { count: 'exact' })
      .eq('is_active', true)
      .order('avg_rating', { ascending: false })
      .range(offset, offset + limit - 1);

    // Keyword search across business_name, description, tags
    if (q) {
      query = query.or(
        `business_name.ilike.%${q}%,description.ilike.%${q}%`
      );
    }

    // City filter
    if (city) query = query.ilike('city', `%${city}%`);

    // Category filter
    if (category) {
      const { data: cat } = await supabase
        .from('categories')
        .select('id')
        .eq('slug', category)
        .single();
      if (cat) query = query.eq('category_id', cat.id);
    }

    // Price filters
    if (minPrice) query = query.gte('price_min', Number(minPrice));
    if (maxPrice) query = query.lte('price_max', Number(maxPrice));

    // Rating filter
    if (minRating) query = query.gte('avg_rating', Number(minRating));

    const { data, error, count } = await query;
    if (error) throw error;

    // Location-based filtering (if lat/lng provided, filter by radius using Haversine)
    let results = data ?? [];
    if (lat && lng) {
      results = results.filter((v) => {
        if (!v.lat || !v.lng) return true; // include vendors without coords
        const R = 6371;
        const dLat = ((v.lat - lat) * Math.PI) / 180;
        const dLng = ((v.lng - lng) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) ** 2 +
          Math.cos((lat * Math.PI) / 180) *
          Math.cos((v.lat * Math.PI) / 180) *
          Math.sin(dLng / 2) ** 2;
        const dist = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return dist <= radius;
      });
    }

    return NextResponse.json({
      vendors: results,
      total: count,
      page,
      limit,
      pages: Math.ceil((count ?? 0) / limit)
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Search failed' }, { status: 500 });
  }
}
