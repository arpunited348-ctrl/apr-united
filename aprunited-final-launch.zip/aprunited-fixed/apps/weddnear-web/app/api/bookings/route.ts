import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';

// GET /api/bookings — get current user's bookings
export async function GET(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');

    let query = supabase
      .from('bookings')
      .select(`
        *,
        vendors(id, business_name, slug, cover_image, city, categories(name, icon))
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (status) query = query.eq('status', status);

    const { data, error } = await query;
    if (error) throw error;

    return NextResponse.json({ bookings: data });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch bookings' }, { status: 500 });
  }
}

// POST /api/bookings — send enquiry / create booking
export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const {
      vendor_id, event_date, event_type, guest_count,
      message, budget, contact_name, contact_phone, contact_email
    } = body;

    if (!vendor_id) {
      return NextResponse.json({ error: 'vendor_id is required' }, { status: 400 });
    }

    // Check vendor exists and is active
    const { data: vendor } = await supabase
      .from('vendors')
      .select('id')
      .eq('id', vendor_id)
      .eq('is_active', true)
      .single();

    if (!vendor) return NextResponse.json({ error: 'Vendor not found' }, { status: 404 });

    const { data, error } = await supabase
      .from('bookings')
      .insert({
        vendor_id, user_id: user.id,
        event_date, event_type, guest_count,
        message, budget,
        contact_name, contact_phone, contact_email
      })
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json({ booking: data }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create booking' }, { status: 500 });
  }
}
