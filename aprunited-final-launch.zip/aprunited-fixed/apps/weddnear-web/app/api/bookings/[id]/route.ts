import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';

// PATCH /api/bookings/[id] — update status or vendor response
export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const { status, vendor_response } = body;

    // Fetch booking with vendor info
    const { data: booking } = await supabase
      .from('bookings')
      .select('*, vendors(user_id)')
      .eq('id', id)
      .single();

    if (!booking) return NextResponse.json({ error: 'Booking not found' }, { status: 404 });

    const isVendor = booking.vendors?.user_id === user.id;
    const isOwner = booking.user_id === user.id;

    if (!isVendor && !isOwner) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    // User can only cancel their own pending booking
    if (isOwner && !isVendor) {
      if (status !== 'cancelled') {
        return NextResponse.json({ error: 'Users can only cancel bookings' }, { status: 403 });
      }
    }

    const updates: Record<string, unknown> = {
      updated_at: new Date().toISOString()
    };
    if (status) updates.status = status;
    if (vendor_response && isVendor) {
      updates.vendor_response = vendor_response;
      updates.responded_at = new Date().toISOString();
    }

    const { data, error } = await supabase
      .from('bookings')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json({ booking: data });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to update booking' }, { status: 500 });
  }
}
