import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';

// GET /api/categories
export async function GET() {
  try {
    const supabase = await createClient();

    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('name');

    if (error) throw error;
    return NextResponse.json({ categories: data });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch categories' }, { status: 500 });
  }
}
