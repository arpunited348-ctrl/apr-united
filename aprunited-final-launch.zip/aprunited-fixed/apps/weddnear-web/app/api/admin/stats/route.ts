import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase-server';

// GET /api/admin/stats
export async function GET() {
  try {
    const supabase = await createAdminClient();

    const [
      { count: totalVendors },
      { count: totalUsers },
      { count: totalBookings },
      { count: pendingReviews },
      { count: pendingVendors }
    ] = await Promise.all([
      supabase.from('vendors').select('*', { count: 'exact', head: true }),
      supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'user'),
      supabase.from('bookings').select('*', { count: 'exact', head: true }),
      supabase.from('reviews').select('*', { count: 'exact', head: true }).eq('is_approved', false),
      supabase.from('vendors').select('*', { count: 'exact', head: true }).eq('is_verified', false).eq('is_active', true)
    ]);

    // Recent bookings
    const { data: recentBookings } = await supabase
      .from('bookings')
      .select('*, vendors(business_name), profiles(full_name, email)')
      .order('created_at', { ascending: false })
      .limit(5);

    return NextResponse.json({
      stats: {
        totalVendors,
        totalUsers,
        totalBookings,
        pendingReviews,
        pendingVendors
      },
      recentBookings
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch stats' }, { status: 500 });
  }
}
