import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase-server';

// GET /api/admin/reviews — pending reviews
export async function GET(request: Request) {
  try {
    const supabase = await createAdminClient();
    const { searchParams } = new URL(request.url);
    const approved = searchParams.get('approved') ?? 'false';

    const { data, error } = await supabase
      .from('reviews')
      .select('*, vendors(business_name), profiles(full_name, email)')
      .eq('is_approved', approved === 'true')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return NextResponse.json({ reviews: data });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch reviews' }, { status: 500 });
  }
}

// PATCH /api/admin/reviews — approve or reject
export async function PATCH(request: Request) {
  try {
    const supabase = await createAdminClient();
    const { review_id, is_approved } = await request.json();
    if (!review_id) return NextResponse.json({ error: 'review_id required' }, { status: 400 });

    if (is_approved === false) {
      // Reject = delete
      const { error } = await supabase.from('reviews').delete().eq('id', review_id);
      if (error) throw error;
      return NextResponse.json({ success: true, action: 'deleted' });
    }

    const { data, error } = await supabase
      .from('reviews')
      .update({ is_approved: true })
      .eq('id', review_id)
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json({ review: data, action: 'approved' });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to update review' }, { status: 500 });
  }
}
