import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';

// GET /api/reviews?vendor_id=xxx
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const vendorId = searchParams.get('vendor_id');
    if (!vendorId) return NextResponse.json({ error: 'vendor_id required' }, { status: 400 });

    const supabase = await createClient();

    const { data, error } = await supabase
      .from('reviews')
      .select('*, profiles(full_name, avatar_url)')
      .eq('vendor_id', vendorId)
      .eq('is_approved', true)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return NextResponse.json({ reviews: data });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch reviews' }, { status: 500 });
  }
}

// POST /api/reviews — submit a review (user must have a booking with this vendor)
export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { vendor_id, booking_id, rating, title, body } = await request.json();

    if (!vendor_id || !rating) {
      return NextResponse.json({ error: 'vendor_id and rating are required' }, { status: 400 });
    }

    if (rating < 1 || rating > 5) {
      return NextResponse.json({ error: 'Rating must be between 1 and 5' }, { status: 400 });
    }

    // Optional: verify user had a completed booking with this vendor
    if (booking_id) {
      const { data: booking } = await supabase
        .from('bookings')
        .select('id')
        .eq('id', booking_id)
        .eq('user_id', user.id)
        .eq('vendor_id', vendor_id)
        .eq('status', 'completed')
        .single();

      if (!booking) {
        return NextResponse.json({ error: 'No completed booking found for this vendor' }, { status: 403 });
      }
    }

    const { data, error } = await supabase
      .from('reviews')
      .insert({ vendor_id, user_id: user.id, booking_id, rating, title, body })
      .select()
      .single();

    if (error) {
      if (error.code === '23505') {
        return NextResponse.json({ error: 'You have already reviewed this vendor' }, { status: 409 });
      }
      throw error;
    }

    return NextResponse.json({
      review: data,
      message: 'Review submitted and pending approval.'
    }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to submit review' }, { status: 500 });
  }
}
