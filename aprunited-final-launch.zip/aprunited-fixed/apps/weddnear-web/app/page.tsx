import Link from 'next/link';

const categories = [
  { name: 'Venues', slug: 'venues', icon: '🏛️' },
  { name: 'Photographers', slug: 'photographers', icon: '📷' },
  { name: 'Caterers', slug: 'caterers', icon: '🍽️' },
  { name: 'Decorators', slug: 'decorators', icon: '🌸' },
  { name: 'Mehendi Artists', slug: 'mehendi', icon: '🖐️' },
  { name: 'Makeup Artists', slug: 'makeup', icon: '💄' },
  { name: 'DJ & Music', slug: 'music', icon: '🎵' },
  { name: 'Pandit & Rituals', slug: 'pandit', icon: '🪔' },
  { name: 'Videographers', slug: 'videographers', icon: '🎥' },
  { name: 'Wedding Planners', slug: 'planners', icon: '📋' },
];

export default function HomePage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-16">
      {/* Header */}
      <div className="mb-4 flex items-center gap-2">
        <span className="text-rose-500 font-semibold">WeddNear</span>
        <span className="text-slate-400 text-sm">·</span>
        <Link href="https://aprunited.io" className="text-slate-400 text-sm hover:text-slate-600">
          an APR United product
        </Link>
      </div>

      <h1 className="mb-4 text-5xl font-bold leading-tight text-slate-900">
        Find your perfect wedding vendor, near you.
      </h1>
      <p className="mb-10 max-w-2xl text-lg text-slate-500">
        Browse verified venues, photographers, caterers and more — filtered by city, price, and rating.
      </p>

      {/* Search bar */}
      <div className="mb-14 flex gap-3">
        <input
          className="flex-1 rounded-xl border border-slate-200 px-5 py-3 text-sm shadow-sm outline-none focus:border-rose-300 focus:ring-2 focus:ring-rose-100"
          placeholder="Search photographers, venues, caterers..."
        />
        <input
          className="w-44 rounded-xl border border-slate-200 px-4 py-3 text-sm shadow-sm outline-none focus:border-rose-300"
          placeholder="City (e.g. Mumbai)"
        />
        <button className="rounded-xl bg-rose-500 px-6 py-3 text-sm font-semibold text-white hover:bg-rose-600 transition-colors">
          Search
        </button>
      </div>

      {/* Categories */}
      <h2 className="mb-6 text-xl font-semibold text-slate-800">Browse by category</h2>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5">
        {categories.map((cat) => (
          <Link
            key={cat.slug}
            href={`/vendors?category=${cat.slug}`}
            className="card flex flex-col items-center gap-2 p-5 text-center hover:border-rose-200 hover:shadow-md transition-all"
          >
            <span className="text-3xl">{cat.icon}</span>
            <span className="text-sm font-medium text-slate-700">{cat.name}</span>
          </Link>
        ))}
      </div>

      {/* Footer attribution */}
      <p className="mt-16 text-center text-xs text-slate-400">
        WeddNear is a product by{' '}
        <a href="https://aprunited.io" className="text-slate-500 hover:underline">APR United</a>.
        Your trusted wedding marketplace.
      </p>
    </main>
  );
}
