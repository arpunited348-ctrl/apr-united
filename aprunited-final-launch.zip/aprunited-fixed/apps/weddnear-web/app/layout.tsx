import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'WeddNear — Find Your Perfect Wedding Vendor',
  description: 'Discover verified wedding vendors near you. Venues, photographers, caterers and more. A product by APR United.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-slate-900">
        {children}
      </body>
    </html>
  );
}
