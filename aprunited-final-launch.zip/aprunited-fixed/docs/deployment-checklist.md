# Deployment Checklist

## Cloudflare
- Set SSL/TLS to Full (strict)
- Add apex A record: `@ -> 76.76.21.21`
- Add CNAME: `www -> cname.vercel-dns-0.com`
- Add CNAME: `sootheai -> cname.vercel-dns-0.com`

## Vercel
- Create project for `apps/apr-united-web`
- Create project for `apps/sootheai-web`
- Add custom domains
- Set environment variables

## Supabase
- Create project
- Enable email auth
- Run `schema.sql`
- Run `policies.sql`
- Configure redirect URLs

## Launch QA
- Signup/login works
- Chat saves to history
- Pricing page visible
- Privacy/terms available
- Error states handled
